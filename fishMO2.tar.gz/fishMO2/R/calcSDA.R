calcSDA <- function(X, Y, my.smr, tau=0.2, lambda=24, postfeed.acclim=6,
             tol=0.05, tol.type=c("proportion", "constant"), 
             MO2.time.unit=c("hour", "min", "day"), X.time.unit=c("hour", "min", "day")) {
        my.data = data.frame(X, Y)
        my.data <- na.omit(my.data)
        names(my.data)[1:2]= c("time", "MO2")
        # time axis must be in hours. If it is not, we transform it.
        if(X.time.unit != "hour"){
            if(X.time.unit == "min") {my.data$time = my.data$time/60} else {my.data$time = my.data$time * 24}
        }
        
        my.data = subset(my.data, X >= 0)
        
        time.step = 0.25 # in hours, we predict SDA every 15 min, 0.25 h
        my.data.2 <- subset(my.data, time >= postfeed.acclim - time.step)  
            # shorter dataset, after removal of the data that are too influenced by 
            # the feeding procedure. The rqss fit will use this shorter data set
            # To be able to predict a SDA right after the end of the period excluded
            #   by the user, it is necessary to include at least one value of MO2 
            #   recorded before. Thus we start with post.feed.acclim - time.step
        pred.x <- data.frame(time=seq(postfeed.acclim, max(my.data.2$time), time.step)) 
            # X to predict, in 0.25 h steps
        # model MO2 to calculate SDA
        fitsda <- rqss(MO2 ~ qss(time, lambda=lambda), tau=tau, data=my.data.2) 
        pred <- predict(fitsda, pred.x)
        sda <- data.frame(time=pred.x$time, pred)
        sda$net <- sda$pred - my.smr
        
        # ASSUMPTION: duration > 10 h, necessary to determine end of SDA. This is because I calculated "net" above
        #    and I look for when net becomes very small. But net can also be very small at the beginning of SDA.
        #    This function has been used by people who did not wait for MO2 to return to SMR before ending the experiment and therefore 
        #    "net" at the end can be a greater value than at the beginning. By assuming that the end comes at least 10 h after feeding time
        #    I avoid the problem
        
        if(tol.type == "proportion") {  # tolerance can be in % of SMR or a fixed value
            endPoint = tol*my.smr
        } else {endPoint = tol}         # endPoint is net, i.e. above SMR
        
        end <- subset(sda, time>(max(10, postfeed.acclim)) & net < endPoint)[1,1] 
        end.mo2 <- tol  # to indicate that we did return to expected endPoint, 
                        # otherwise this gets changed below
        if(is.na(end)){
            sda.end = subset(sda, time>max(10, postfeed.acclim))
            sda.stop = subset(sda.end, net == min(net))
            end = sda.stop$time  # time for lowest post-feeding MO2
            if(tol.type == "proportion") {
                closest = sda.stop$net / my.smr   
                # SDA stopped at X% above smr, normally 5%. 
                # When we do not reach the expected value, we use the lowest reached
                end.mo2 <- round(closest,3)
            } else {
                end.mo2 = sda.stop$net
            }
        }
        
        if (postfeed.acclim > 0) {  
            # if a few hours were excluded immediately after feeding
            # we need to add a line to the sda dataframe for time zero
            dummy = data.frame(time=0, pred=my.smr, net=0)
            sda = rbind(dummy,sda)
        }
        
        duringSDA = sda$net>0 & sda$time<end
        
        sda$status[duringSDA] = "sda"
        sda$status[sda$time==0] = "start"
        sda$status[is.na(sda$status)] = "post-sda"
        sda.short = subset(sda, status %in% c("start","sda"))
        if(nrow(sda.short)==0) { # something went wrong, we have no usable SDA
            sda.dur.h = NA
            sda.peak = data.frame(time=NA, pred=NA, net=NA)
            area.net=NA
            end.mo2=NA	
        } else {	# normal situation
            sda.dur.h <- max(sda.short$time)
            sda.peak <- sda.short[sda.short$pred == max(sda.short$pred),1:3] 
            
            # to compute area under the curve
            area.net <- trap.rule(sda.short$time, sda.short$net)
            # if time base of MO2 is in minutes instead of hours, multiply by 60
            if(MO2.time.unit == "min"){
                area.net = area.net*60
            }
            if(MO2.time.unit == "day"){
                area.net = area.net/24
            }
         } # end sda data not empty
        
        the.sda <- data.frame(c(
            duration=sda.dur.h, 
            peak=sda.peak, 
            magnitude=area.net, 
            end.MO2=as.numeric(end.mo2), 
            SMR=my.smr, 
            tau=tau, 
            lambda=lambda))
        names(the.sda)[which(names(the.sda) == "peak.pred" )] = "peak"
        rq.out <- list(sda.fit=sda, sda.var=the.sda)
        rq.out             # output a list with SDA curve and SDA variables
}	# end function
