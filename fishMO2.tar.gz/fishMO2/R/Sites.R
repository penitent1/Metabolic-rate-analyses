Sites = list(La_Rochelle = c(46.162, -1.152), 
             Sete = c(43.4018, 3.6966), 
             IML = c(48.5833, -69.2), 
             Helsingor = c(56.0361, 12.6136), 
             Brest = c(48.39972, -4.483056), 
             Vancouver = c(49.24944, -123.1192)
)