calcSMR = function(Z, q=c(0.05,0.1,0.15,0.2,0.25,0.3,0.4,0.5), G=1:4){
    # require(mclust)
    Z = Z[!is.na(Z)]  # remove NAs
    u = sort(Z)
    the.Mclust <- Mclust(Z,  G=G)
    cl <- the.Mclust$classification
    # sometimes, a small distribution of outliers is identified which does not constitute SMR
    # the following presumes that when class 1 contains more than 10% of cases, it contains SMR, otherwise class 2 is used
    cl2 <- as.data.frame(table(cl))
    cl2$cl <- as.numeric(levels(cl2$cl))
    valid <- cl2$Freq>=0.1*length(cl)
    the.cl <- min(cl2$cl[valid])
    left.distr <- Z[the.Mclust$classification==the.cl]
    mlnd = the.Mclust$parameters$mean[the.cl]
    popID = the.cl
    CVmlnd = sd(left.distr)/mlnd * 100
    quant=quantile(u, p=q)
    low10=mean(u[1:10])
    if(length(u) >= 35) { # to have at least 3 values for SMR
        low10pc = mean(u[6:(5 + round(0.1*(length(u)-5)))])  # remove 5 outliers, keep lowest 10% of the rest, average
    } else low10pc = NA
    twopc = round(0.02*N(u),0)
    low10_2pc = mean(u[twopc+1:twopc+11])  # remove 2% of values as outliers, keep 10 lowest to average

    Z = list(mlnd=mlnd, quant=quant, low10=low10, low10pc=low10pc, low10_2pc = low10_2pc, cl=cl, theSMRdistr=popID, CVmlnd=CVmlnd)
    return(Z)
}
