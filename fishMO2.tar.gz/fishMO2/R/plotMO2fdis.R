plotMO2fdis = function(X, g=1:4, Breaks=100, mo2lab=expression(M[O[2]]), Border.col = grey(0.5), Bar.col=grey(0.92), ColNormdis = "blue", ...){
    u = sort(X)
	hist(u, breaks=Breaks, freq=F, main="", border=Border.col, col=Bar.col, xlab=mo2lab, ...) 
	rug(u, ticksize = 0.01, quiet = TRUE)

	myBIC <- mclustBIC(X, G=g)
	myModel <- summary(myBIC, X)
	newX <- seq(from = min(X), to = max(X), length = 500)
	Dens <- dens(modelName = myModel$modelName, data = newX,
				parameters = myModel$parameters)
	lines(newX, Dens, col=ColNormdis)			
	myModel$parameters$mean
}
