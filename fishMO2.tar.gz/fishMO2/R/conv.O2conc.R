conv.O2conc <- function(x, from=c("mg", "ml", "umol", "mmol"), to=c("umol", "mg", "ml", "mmol")){
    if (!is.numeric(x)) 
        stop("x must be numeric")    
    from <- match.arg(from)
    to <- match.arg(to)
    switch(from,
        mg = switch(to,
            ml = {
                z = x / 1.42905  # Garcia
            },
            umol = {
                z = x / 0.0319988   # Weast et al. 1986; Masterton et al. 1974; Wikipedia; Benson & Krause 1984
                                    # 31.9988 g / mole = 0.031988 mg / micromole
            },
            mmol = {
                z = x / 31.9988   # 31.9988 mg / mmol
            }),
        ml = switch(to,
            mg = {
                z = x * 1.42905  # Garcia
            },
            umol = {
                z = x / 0.0223916   # Garcia & Gordon 1992 22.3916 l/mol, but Benson & Krause 1980 & 1984 use 22.414
                                    # and Weast uses 0.022292 
            },
            mmol = {
                z = x / 22.3916 
            }),
        umol = switch(to,
            mg = {
                z = x * 0.0319988  # Weast et al. 1986; Benson & Krause 1984
                                   # http://www.helcom.fi/stc/files/CombineManual/PartB/ANNEXB-7.pdf
            },
            ml = {
                z = x * 0.0223916   # Garcia & Gordon 1992 22.3916 l/mol, but Benson & Krause 1980 & 1984 use 22.414
                                    # and Weast uses 0.022292 
            },
            mmol = {
                z = x / 1000 
            }),
        mmol = switch(to,
            mg = {
                z = x * 31.9988              
            },
            ml = {
                z = x * 22.3916 / 1000 
            },
            umol = {
                z = x * 1000 
            })
    )
    z
}