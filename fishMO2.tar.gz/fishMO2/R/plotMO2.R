plotMO2 = function(x, y, mo2="dotital", o2="umol", t="hr", m="kg", showO2 = F, Xlab = "Time (month-day)", ...){
    Ylab = makeO2lab(mo2=mo2, o2=o2, t=t, m=m, showO2 = showO2)
    plot(y ~ x, ylab=Ylab, xlab=Xlab, xaxt="n", bty="l", ...)
    if("POSIXct" %in% class(x)){
        r = range(x)
        ndays = as.numeric(difftime(r[2],r[1], units="day"))
        t <- as.POSIXct(round(r, "days"))
        t[1] = t[1] - 24*60*60
        t[2] = t[2] + 24*60*60
        if(ndays<1.5){
            axis.POSIXct(1, at=seq(t[1], t[2], by=6*60*60), format="%H", tck=-0.014)
        } else { # longer session
            axis.POSIXct(1, at = seq(t[1], t[2], by = "days"), format = "%m-%d")
            axis(1, at=seq(t[1], t[2], by = 6*60*60), labels=F, tck = -0.007)
        }
    } else { # end if POSIX, assuming time is in hours
        axis(1, at=seq(-120, 240, 24), labels=seq(-120, 240, 24), tick=T, tck=-0.014)
        axis(1, at=seq(-120, 240, 6), labels=F, tck = -0.007)
    }
}