makeO2lab = function(mo2=c("dotital", "dot", "ital", "plain"), 
                     o2=c("mg", "ug", "mmol", "umol", "ml", "mL"), 
                     t=c("hr", "min"),          
                     m=c("kg", "g", "mg"),
                     v=c("l", "L"),
                     showO2 = F,
                     Type=c("MO2msp", "MO2ind", "SDAmsp", "SDAind", "conc")
                     ) {
    mo2 <- match.arg(mo2)
    switch(mo2,
        plain = {
            labmo2 = quote(M[O[2]])
        },
        ital = {
            labmo2 = quote(italic(M)[O[2]])
        },
        dot = {
           labmo2 = quote(dot(M)[O[2]])
        },
        dotital = {
           labmo2 = quote(italic(dot(M))[O[2]])
        }   
    )

        o2 <- match.arg(o2)
    switch(o2,
        mg = {
            labo2 = "mg"
        },
        ug = {
            labo2 = quote(mu*"g")
        },
        mmol = {
            labo2 = "mmol"
        },
        umol = {
           labo2 = quote(mu*"mol")
        },
        ml = {
           labo2 = "ml"
        },
        mL = {
           labo2 = "mL"
        }
    )
    
    if(showO2){
        Type <- match.arg(Type)
        switch(Type,
            MO2ind = {
                Lab = substitute(a ~ "(" * b ~ O[2] ~ c^-1 * ")", list(a = labmo2, b = labo2, c=t))
            },
            MO2msp = {
                Lab = substitute(a ~ "(" * b ~ O[2] ~ c^-1 ~ d^-1 * ")", list(a = labmo2, b = labo2, c=t, d=m))
            },
            SDAind = {
                Lab = substitute("SDA (" * b ~ O[2] * ")", list(b = labo2))
            },
            SDAmsp = {
                Lab = substitute("SDA (" * b ~ O[2] ~ d^-1 * ")", list(b = labo2, d=m))
            },
            conc = {
                Lab = substitute("DO (" * b ~ O[2] ~ e^-1 * ")", list(b = labo2, e=v))
            }  ) 
    } else {  # don't display "O2" after oxygen unit
        Type <- match.arg(Type)
        switch(Type,
            MO2ind = {
                Lab = substitute(a ~ "(" * b ~ c^-1 * ")", list(a = labmo2, b = labo2, c=t))
            },
            MO2msp = {
                Lab = substitute(a ~ "(" * b ~ c^-1 ~ d^-1 * ")", list(a = labmo2, b = labo2, c=t, d=m))
            },
            SDAind = {
                Lab = substitute("SDA (" * b  * ")", list(b = labo2))
            },
            SDAmsp = {
                Lab = substitute("SDA (" * b ~ d^-1 * ")", list(b = labo2, d=m))
            },
            conc = {
                Lab = substitute("DO (" * b ~ e^-1 * ")", list(b = labo2, e=v))
            }
        )
    }
    Lab
}