plotO2crit <- function(o2critobj, plotID="", o2lab="Dissolved oxygen (% sat.)",
    mo2lab=expression(M[O[2]]), smr.cex=0.9, o2crit.cex=0.9, plotID.cex=1.2, Transparency=T, ...)
{
    smr = o2critobj$SMR
    if(Transparency) Col=c(rgb(0,0,0,0.7), "red", "orange") else Col=c(grey(0.3), "red", "orange")
    Data=o2critobj$origData
    Data$Color = Col[1]
    Data$Color[o2critobj$lethalPoints] = Col[2]
    Data$Color[o2critobj$AddedPoints] = Col[3]
    # ordinary LS regression, without added points: blue line, red symbols
    # ordinary LS regression, with added points: blue line, red & orange symbls
    # regression through origin, green dotted line, red symbols
    line.color = ifelse(o2critobj$Method=="LS_reg", "blue", "darkgreen")
    line.type = ifelse(o2critobj$Method=="LS_reg", 1, 3)
    limX = c(0, max(Data$DO))
    limY = c(0, max(Data$MO2))
    plot(MO2~DO, data=Data, xlim=limX, ylim=limY, col=Data$Color, xlab=o2lab, 
       ylab=mo2lab, ...)
    coord <- par("usr")
    if(plotID != ""){
    text(0, coord[4], plotID, cex=plotID.cex, adj=c(0,1.2))    
    }
    
    abline(h=smr, col="orange")
    text(coord[1], smr, "SMR", adj=c(-0.1,1.3), cex=smr.cex)
    text(coord[1], smr, round(smr,1), adj=c(-0.1,-0.3), cex=smr.cex)
    if(!is.na(o2critobj$o2crit)) {
    	abline(o2critobj$mod, col=line.color, lty=line.type)
    	segments(o2critobj$o2crit, smr, o2critobj$o2crit, coord[3], 
             col=line.color, lwd=1)
    text(x=o2critobj$o2crit, y=0, o2critobj$o2crit, col=line.color, 
         cex=o2crit.cex, adj=c(-0.1,0.5))
    	} 
}
