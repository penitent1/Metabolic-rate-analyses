plotSDA <- function(my.sda, show.par=T, show.var=T, show.smr.line=T, show.feeding=T, show.mag.arrow=T,
                    peak.lab.pos=NULL, mag.lab.pos=NULL, smr.lab.pos=c("2L", "1L", "none"),  
                    lty.smr =1, col.smr="orange", 
                    lty.feeding=1, Col.feeding="seagreen", Cex.par=0.8, Cex.sda=0.9, 
                    Col.sda=rgb(1,0,0,0.2),  ...) {

    smr.lab.pos = match.arg(smr.lab.pos)
    sda.var = my.sda$sda.var
    sda.fit <- my.sda$sda.fit
    sda.short = subset(sda.fit, status %in% c("start","sda")) # to draw the SDA polygon

    # this needs improvements, but works
    # required to properly format different scales
    rnd = ifelse(sda.var$peak.net <= 1, 3, ifelse(sda.var$peak.net <= 10, 2, 1))
    
    coords = par("usr")
    deltax = coords[2] - coords[1]
    deltay = coords[4] - coords[3]
    deltax2 = coords[2] - sda.var$peak.time
    deltay2 = coords[4] - sda.var$peak

    # if requested, indicate the values of tau and lambda in upper left corner
    if(show.par){
        text(par("usr")[1], par("usr")[4], 
             substitute(list(tau, lambda) == group("(",list(x,y),")"),
             list(x=sda.var$tau, y=sda.var$lambda)), 	adj = c(-0.1,1.1), cex=Cex.par)
    }
    
    # if requested show SMR line
    if(show.smr.line) abline(h=sda.var$SMR, lty=lty.smr, col=col.smr)
    # if requested, print "SMR" along with its value
    if(smr.lab.pos == "1L") {
        smr.text = as.expression(substitute(SMR ==l, list(l=round(sda.var$SMR,rnd))))
        text(coords[1] + 0.01*deltax, sda.var$SMR, smr.text, adj = c(0,1.5), cex=Cex.sda )
    } else if(smr.lab.pos=="2L"){
        text(coords[1], sda.var$SMR, "SMR", adj=c(-0.1,1.3), cex=Cex.sda)
        text(coords[1], sda.var$SMR, round(sda.var$SMR,1), adj=c(-0.1,-0.3), cex=Cex.sda)
    }

    if(show.feeding){
        abline(v=0, lty=lty.feeding, col=Col.feeding)    
    }  
    
    # to draw a polygon representing SDA
    new.x <- c(sda.short$time, sda.short$time[length(sda.short$time)], sda.short$time[1]) 
    new.y <- c(sda.short$pred, sda.var$SMR, sda.var$SMR)
    polygon(new.x, new.y, col=Col.sda)

    if(show.var){
        # add peak label and arrow
        # if the user has not specified the coordinates of the label for the peak of SDA, 
        #   automatically determine a position that will be likely acceptable
        #   note: the user can specify the coordinates in peak.lab.pos as a x and y pair 
        #   with c(x, y)
        arrow.start = c(sda.var$peak.time+0.005*deltax, sda.var$peak+0.005*deltay)
        if (is.null(peak.lab.pos)) {
            peak.lab.pos = c(sda.var$peak.time+0.25*deltax2, sda.var$peak+0.2*deltay2)
        }
        
        # place SDA variables on plot
        # peak & peak time
        peak.net.text = as.expression(substitute("peak (net)"==m, 
                                      list(m=round(sda.var$peak.net,rnd))))
        peak.time.text = paste("at", round(sda.var$peak.time,1), "h")
        Arrows(arrow.start[1], arrow.start[2], peak.lab.pos[1], peak.lab.pos[2], 
               arr.length = 0.2, code=1, arr.adj=1)    # arrow toward peak   
        text(peak.lab.pos[1], peak.lab.pos[2], peak.net.text, adj = c(-0.05,0.3), cex=Cex.sda )
        text(peak.lab.pos[1], peak.lab.pos[2], peak.time.text, adj = c(-0.4,1.5), cex=Cex.sda )
            
        # duration
        duration.text = paste0("duration = ", round(sda.var$duration,1), " h")
        text(sda.var$duration/2, sda.var$SMR, duration.text, adj = c(0.5,1.5), cex=Cex.sda)

        # magnitude and arrow
        if (is.null(mag.lab.pos)) {
            mag.lab.pos = c(sda.var$duration/2, sda.var$SMR)
        }
        magnitude.text = as.expression(substitute(magnitude ==z, 
                                       list(z=round(sda.var$magnitude,rnd-1))))
        text(mag.lab.pos[1], mag.lab.pos[2], magnitude.text, 
             cex=Cex.sda, adj = c(0.5,2.5) )  # one fewer signif. digit than peak
        arrowstart.x = sda.var$duration/2 - strwidth(magnitude.text)/2  #+ strwidth("i") 
        arrowstart.y = sda.var$SMR - strheight(magnitude.text)*1.8
        arrowhead.x = ifelse(arrowstart.x > 3, min(sda.var$peak.time, arrowstart.x), 
                             sda.var$peak.time)
        arrowhead.y = sda.var$SMR + sda.var$peak.net/2
        if(show.mag.arrow){
            Arrows(arrowhead.x, arrowhead.y, arrowstart.x, arrowstart.y, arr.length = 0.2, 
                   code=1, arr.adj=1)    # arrow toward peak 
            }
        } # end show variables
}	# end function
