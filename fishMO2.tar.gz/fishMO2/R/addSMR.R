addSMR <- function(SMR, SMRcol="orange", SMRcex=0.85, showLabel=T, ...) {
        coord = par("usr")  # in future version, check if a plot exists and exit if there is none
        abline(h=SMR, col=SMRcol, ...)
        if(showLabel) text(coord[1], SMR, paste("SMR = ", round(SMR,1), sep=""), adj=c(-0.1,1.3), cex=SMRcex)
}
