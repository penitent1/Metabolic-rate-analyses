drawNights <- function(startD, endD, Site=Sites$IML, TimeZone=myTZs$IMLst, coords, 
                       XunitsOut="POSIXct", zero=NA, night.col=rgb(0,0,0,0.08)) { 
    nbDays = as.integer(endD - startD) + 2     # sunrise.set seems to start the day before my start date, so I must add one day, then start date, then diff between start and end
	pp <- sunrise.set(Site[1], Site[2], as.character(startD-1), timezone=TimeZone, nbDays) 
	if (nrow(pp)>1 ) {
		lights_on = pp$sunrise[2:nrow(pp)]
		lights_off = pp$sunset[1:(nrow(pp)-1)]
#         Xcoords = as.POSIXct(coords[1:2], origin="1970-01-01", tz=TZone)
		if(XunitsOut=="POSIXct") {
			for(m in 1:length(lights_off)) {
				x = c(lights_off[m], lights_off[m], lights_on[m], lights_on[m])  # this uses local time zone!
                attr(x, "tzone") <- TimeZone  # new line added 2014-09-21
				y = c(coords[3], coords[4], coords[4], coords[3])
				polygon(x, y, col=night.col, border=NA)
				}  # end for m
		} else if (XunitsOut=="hours"){
			lights_off2 = as.numeric(difftime(lights_off, zero, units="hours"))
			lights_on2 = as.numeric(difftime(lights_on, zero, units="hours"))
			for(m in 1:length(lights_off2)) {
				x = c(lights_off2[m], lights_off2[m], lights_on2[m], lights_on2[m]) 
				y = c(coords[3], coords[4], coords[4], coords[3])
				polygon(x, y, col=night.col, border=NA)
				}  # end for m
		} # end XunitsOut
	} # end for if nrow
} # end function
