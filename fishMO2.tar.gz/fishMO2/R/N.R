N = function(x){
    sum(!is.na(x))
}
