###
# final version for O2crit paper
calcO2crit <- function(Data, SMR, lowestMO2=NA, gapLimit = 4,
                       max.nb.MO2.for.reg = 20)
{
    # programmed by Denis Chabot, Institut Maurice-Lamontagne, DFO, Canada
    # first version written in June 2009
    # last updated in January 2015

    Data = na.omit(Data)
    method = "LS_reg"  # will become "through_origin" if intercept is > 0
    if(is.na(lowestMO2)) lowestMO2 = quantile(Data$MO2[Data$DO >= 80], p=0.05)

    # Step 1: identify points where MO2 is proportional to DO
    geqSMR = Data$MO2 >= lowestMO2
    pivotDO = min(Data$DO[geqSMR])
    lethal = Data$DO < pivotDO
    N_under_SMR = sum(lethal)  	# points available for regression?
    final_N_under_SMR = lethal  # some points may be removed at Step 4
    lastMO2reg = Data$MO2[Data$DO == pivotDO] # last MO2 when regulating
    if(N_under_SMR > 1) theMod = lm(MO2~DO, data=Data[lethal,])

    # Step 2, add one or more point at or above SMR
    # 2A, when there are fewer than 3 valid points to calculate a regression
    if(N_under_SMR < 3){
        missing = 3 - sum(lethal)
        not.lethal = Data$DO[geqSMR]
        DOlimit = max(sort(not.lethal)[1:missing])  # highest DO acceptable
        #  to reach a N of 3
        addedPoints = Data$DO <= DOlimit
        lethal = lethal | addedPoints
        theMod = lm(MO2~DO, data=Data[lethal,])
    }

    # 2B, add pivotDO to the fit when Step 1 yielded 3 or more values?
    if(N_under_SMR >= 3){
        lethalB = Data$DO <= pivotDO # has one more value than "lethal"
        regA = theMod
        regB = lm(MO2~DO, data=Data[lethalB,])
        large_slope_drop = (coef(regA)[2]/coef(regB)[2]) > 1.1 # arbitrary
        large_DO_gap = (max(Data$DO[lethalB]) - max(Data$DO[lethal])) > gapLimit
        tooSmallMO2 = lastMO2reg < SMR
        if(!large_slope_drop & !large_DO_gap & !tooSmallMO2) {
            lethal = lethalB
            theMod = regB
        } # otherwise we do not accept the additional point
    }

    # Step 3
    # if the user wants to limit the number of points in the regression
    if(!is.na(max.nb.MO2.for.reg) & sum(lethal)>max.nb.MO2.for.reg){
        Ranks = rank(Data$DO)
        lethal = Ranks <= max.nb.MO2.for.reg
        theMod = lm(MO2~DO, data=Data[lethal,])
        final_N_under_SMR = max.nb.MO2.for.reg
    }

    # Step 4
    predMO2 = as.numeric(predict(theMod, data.frame(DO=Data$DO)))
    Data$delta = (Data$MO2-predMO2)/predMO2 * 100 # residuals set to zero
    # when below pivotDO
    Data$delta[Data$DO < pivotDO | lethal] = 0
    tol = 0 # any positive residual is unacceptable
    HighValues = Data$delta > tol
    Ranks = rank(-1*Data$delta)
    HighMO2 = HighValues & Ranks == min(Ranks)    # keep largest residual
    if (sum(HighValues) > 0) {
        nblethal = sum(lethal)
        Data$W = NA
        Data$W[lethal]=1/nblethal
        Data$W[HighMO2] = 1
        theMod = lm(MO2~DO, weight=W, data=Data[lethal | HighMO2,])
        # This new regression is always an improvement, but there can still
        # be points above the line, so we repeat
        predMO2_2 = as.numeric(predict(theMod, data.frame(DO=Data$DO)))
        Data$delta2 = (Data$MO2-predMO2_2)/predMO2_2 * 100
        Data$delta2[Data$DO < pivotDO] = 0
        tol = Data$delta2[HighMO2]
        HighValues2 = Data$delta2 > tol
        if(sum(HighValues2)>0){
            Ranks2 = rank(-1*Data$delta2)
            HighMO2_2 = HighValues2 & Ranks2 == 1  # keep the largest residual
            nblethal = sum(lethal)
            Data$W = NA
            Data$W[lethal]=1/nblethal
            Data$W[HighMO2_2] = 1
            theMod2 = lm(MO2~DO, weight=W, data=Data[lethal | HighMO2_2,])
            # is new slope steeper than the old one?
            if(theMod2$coef[2] > theMod$coef[2]) {
                theMod = theMod2
                HighMO2 = HighMO2_2
            }
        } # end second search for high value
    } # end first search for high value

    Coef = coefficients(theMod)

    #Step 5, check for positive intercept
    AboveOrigin = Coef[1] > 0
    # if it is, we use a regression that goes through the origin
    if (AboveOrigin){
        theMod = lm(MO2~DO -1, data=Data[lethal,])
        Coef = c(0, coefficients(theMod)) # need to add the intercept (0)
        #  manually to have a pair of coefficients
        method = "through_origin"
        HighMO2 = rep(FALSE, nrow(Data)) # did not use the additional value
        # from Step 4
    }

    po2crit = as.numeric(round((SMR - Coef[1]) / Coef[2], 1))
    sum_mod = summary(theMod)
    anov_mod = anova(theMod)
    O2CRIT = list(o2crit=po2crit, SMR=SMR, Nb_MO2_conforming = N_under_SMR,
                  Nb_MO2_conf_used = final_N_under_SMR,
                  High_MO2_required = sum(HighMO2) == 1, origData=Data,
                  Method=method, mod=theMod, r2 = sum_mod$r.squared,
                  P = anov_mod$"Pr(>F)", lethalPoints = which(lethal),
                  AddedPoints = which(HighMO2))
    return(O2CRIT)
} # end function

###

