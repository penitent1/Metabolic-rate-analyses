plotR2 <- function(r2, time, mo2, r2lab=expression(r^2), Timelab="Time", mo2lab=expression(M[O[2]]), minR2=NULL, cex=0.7, ...) {
    # First plot
    plot(r2~time, xlab=Timelab, ylab=r2lab, cex=0.7, xaxt="n", ...)
    if("POSIXct" %in% class(time)){
        r = range(time)
        ndays = as.numeric(difftime(r[2],r[1], units="days"))
        t <- as.POSIXct(round(r, "days"))
        t[1] = t[1] - 24*60*60
        t[2] = t[2] + 24*60*60
        if(ndays<1.5){
            axis.POSIXct(1, at=seq(t[1], t[2], by=6*60*60), format="%H", tck=-0.014)
        } else { # longer session
            axis.POSIXct(1, at = seq(t[1], t[2], by = "days"), format = "%m-%d")
            axis(1, at=seq(t[1], t[2], by = 6*60*60), labels=F, tck = -0.007)
        }
    } else {  # numeric X, must be hours
        axis(1, at=seq(-120, 240, 24), labels=seq(-120, 240, 24), tick=T, tck=-0.014)
        axis(1, at=seq(-120, 240, 6), labels=F, tck = -0.007)
    }
    if(!is.null(minR2)) abline(h=minR2, col="red")  # if a first estimate of minR2 already exists, show it
    
    # Second plot
    hist(r2, breaks=seq(0,1,0.01), freq=F, main="", bty="l", border=grey(0.5), xlab=r2lab)
    if(!is.null(minR2)) abline(v=minR2, col="red")
    
    # Third plot
    plot(r2~mo2, xlab=mo2lab, ylab=r2lab, cex=0.7)
    if(!is.null(minR2)) abline(h=minR2, col="red")
}