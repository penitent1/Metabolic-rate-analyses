myTZs = list(
    IMLcivil = "Canada/Eastern", 
    IMLst = "Etc/GMT+5", 
    FRcivil = "Europe/Paris", 
    FRst = "Etc/GMT-1",
    DKcivil = "Europe/Copenhagen",
    DKst = "Etc/GMT-1",
    BCcivil = "Canada/Pacific",
    BCst = "ETC/GMT+8"
)
